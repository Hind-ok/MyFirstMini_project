// LA boite newsletter
function afficher(){
    var boite = document.querySelector(".boite");
    boite.classList.toggle('active');
}